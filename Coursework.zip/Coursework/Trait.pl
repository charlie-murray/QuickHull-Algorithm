:- initialization(main).
/*Begin Question 4.1*/
divisible(X,Y) :- 0 is X mod Y, !.

divisible(X,Y) :- X > Y+1, divisible(X, Y+1).

prime(2) :- true,!.
prime(X) :- X < 2,!,false.
prime(X) :- not(divisible(X, 2)).
    
/*End Question 4.1*/

/*Begin Question 4.2*/
/*possible( X, Y, Z )
  :-*/

/*End Question 4.2*/

/*Begin Question 4.3*/
/*acceptable( X, Y, Z ) 
  :-*/

/*trait( X, Y, Z )
  :-*/

/*End Question 4.3*/

/* any main predicates for testing goes here*/
main:- 
    print(prime(17)).