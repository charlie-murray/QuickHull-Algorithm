-- I acedentally deleted a large amount of my work and this was all that I found was saved on the day I handed it in. Sorry

-- any imports go here
module Main where
import Data.List
import qualified Data.Set as S

{-Begin Question 1.1-}
digits :: Int -> [Int]
digits 0 = []
digits x = digits (x `div` 10) ++ [x `mod` 10]

{-End Question 1.1-}

{-Begin Question 1.2-}
{-Bool-}
testBool :: Int -> Bool
testBool x
    | x == 0 = True
    | x /= 0 = False

isPar :: Int -> Bool
isPar x = 
    let
        y = (x `mod` 100)  `mod`( x `div` 100)
        bools = testBool y
    in
        bools
    
{-pars :: [Int]-}

{-End Question 1.2-}

{-Begin Question 1.3-}
testMod :: (Int, Int, Int, Int) -> Bool
testMod (x,y,z,t)
    | x `mod` z == 0 && y `mod` z == 0 && t == 0 = True
    | otherwise = False
repeated :: [Int] -> Int
repeated [] = 0
repeated (x:y) = if elem x y then 1
                             else repeated y
delRepeated :: [Int]->[Int]->[Int]
delRepeated lst = filter (`notElem` lst)
isParty :: (Int, Int) -> Bool
isParty (x,y) = 
    let
        values =[1,2,3,4,5,6,7,8,9]
        completeList = digits x ++ digits y
        sortedList = sort completeList
        rep = repeated sortedList
        modList = delRepeated sortedList values
        modValue = head modList
        result = testMod(x,y,modValue,rep)
    in
        result
    
{-partys :: [(Int, Int)]-}

{-End Question 1.3-}

-- any main functions for testing goes here
main :: IO ()

main = do
    {-print(digits 9124)-}
    {-print(isPar 2678)-}
    print(isParty (2754, 1836))