-- any imports go here
module Main where

{-Begin Question 2.1-}
number :: [Int] -> Int
number = foldl addDig 0
	where addDig num d = 10*num + d

{-End Question 2.1-}

{-Begin Question 2.2-}
splits :: [a] -> [([a],[a])]
splits [] = []
splits [x] = []
splits (x : xs) = ([x], xs) : map f (splits xs)
  where
    f (z, y) = (x : z, y)

{-possibles :: [([Int],[Int])]-}

{-End Question 2.2-}

{-Begin Question 2.3-}
higher :: (Int, Int) -> Int
higher (x,y) 
    | x <= y = x
    | x >= y = y
lastDig :: Int -> Int
lastDig x
    | (x < 0) = ((-1) * x) `rem` 10
    | otherwise = x `rem` 10
checkThree :: Int -> Int
checkThree x
    | x == 3 = 0
    | x /= 3 = 1
checkFour :: (Int, Int) -> Bool
checkFour (x,y)
    | x == 4 && y == 0 = True
    | otherwise = False
isAcceptable :: ([Int],[Int]) -> Bool
isAcceptable (x,y)
    = let 
        one = number x
        two = number y
        low = higher (one, two)
        mul = one * two
        getLastThree = lastDig low
        getLastFour = lastDig mul
        check1 = checkThree getLastThree
        check2 = checkFour (getLastFour, check1)
    in
        check2

{-acceptables :: [([Int],[Int])]-}

{-End Question 2.3-}

-- any main functions for testing goes here
main :: IO ()

main = do
    {-print(number [9,1,2,4])-}
    {-print(splits [1,2,3,4])-}
    print(isAcceptable ([7,1,6,3], [5,9,2,4,8]))